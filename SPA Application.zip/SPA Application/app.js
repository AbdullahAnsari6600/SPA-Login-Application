document.addEventListener('DOMContentLoaded', () => {
    // Dummy credentials
    const dummyUsername = 'user';
    const dummyPassword = 'password';

    // Simple state management for authentication
    let isAuthenticated = false;
    let activeOrders = [];
    let completedOrders = [];
    let currentEditingOrder = null;

    const app = document.getElementById('app');

    // Function to apply the theme
    const applyTheme = (theme) => {
        if (theme === 'dark') {
            document.documentElement.style.setProperty('--background-color', '#121212');
            document.documentElement.style.setProperty('--text-color', '#ffffff');
            document.documentElement.style.setProperty('--container-background-color', '#333333');
        } else {
            document.documentElement.style.setProperty('--background-color', '#f0f0f0');
            document.documentElement.style.setProperty('--text-color', '#000000');
            document.documentElement.style.setProperty('--container-background-color', '#ffffff');
        }
    };

    // Function to toggle the theme
    const toggleTheme = () => {
        const currentTheme = localStorage.getItem('theme') || 'light';
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        localStorage.setItem('theme', newTheme);
        applyTheme(newTheme);
    };

    // Function to initialize the theme
    const initTheme = () => {
        const savedTheme = localStorage.getItem('theme') || 'light';
        applyTheme(savedTheme);
        document.getElementById('themeSwitch').checked = savedTheme === 'dark';
    };

    // Function to render the login page
    const renderLoginPage = () => {
        app.innerHTML = `
            <h2>Login</h2>
            <div id="error" class="error hidden"></div>
            <form id="loginForm">
                <input type="text" id="username" placeholder="Username" required />
                <input type="password" id="password" placeholder="Password" required />
                <button type="submit">Login</button>
            </form>
        `;

        document.getElementById('loginForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            if (username === dummyUsername && password === dummyPassword) {
                isAuthenticated = true;
                renderHomePage();
            } else {
                const errorDiv = document.getElementById('error');
                errorDiv.textContent = 'Invalid credentials';
                errorDiv.classList.remove('hidden');
            }
        });
    };

    // Function to render the home page
    const renderHomePage = () => {
        if (!isAuthenticated) {
            renderLoginPage();
            return;
        }

        app.innerHTML = `
            <div class="logout-container">
                <button id="logoutButton" class="logout-button">Logout</button>
            </div>
            <h2>Home Page</h2>
            <p>Welcome, ${dummyUsername}!</p>
            <button onclick="openModal('createOrderModal')">Create Sale Order</button>
            <div class="tabs">
                <button class="tablinks active" id="activeTab">Active Sale Orders</button>
                <button class="tablinks" id="completedTab">Completed Sale Orders</button>
            </div>
            <div id="activeOrders" class="tabcontent">
                <h3>Active Sale Orders</h3>
                <table id="activeOrdersTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Customer Name</th>
                            <th>Price</th>
                            <th>Last Modified</th>
                            <th>Edit/View</th>
                            <th>Complete</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
            <div id="completedOrders" class="tabcontent hidden">
                <h3>Completed Sale Orders</h3>
                <table id="completedOrdersTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Customer Name</th>
                            <th>Price</th>
                            <th>Last Modified</th>
                            <th>View</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        `;

        document.getElementById('logoutButton').addEventListener('click', () => {
            isAuthenticated = false;
            renderLoginPage();
        });

        // Tab functionality
        const activeTab = document.getElementById('activeTab');
        const completedTab = document.getElementById('completedTab');
        const activeOrders = document.getElementById('activeOrders');
        const completedOrders = document.getElementById('completedOrders');

        activeTab.addEventListener('click', () => {
            activeTab.classList.add('active');
            completedTab.classList.remove('active');
            activeOrders.classList.remove('hidden');
            completedOrders.classList.add('hidden');
        });

        completedTab.addEventListener('click', () => {
            completedTab.classList.add('active');
            activeTab.classList.remove('active');
            completedOrders.classList.remove('hidden');
            activeOrders.classList.add('hidden');
        });

        renderOrdersTable();
    };

    // Function to render the orders tables
    const renderOrdersTable = () => {
        const activeOrdersTableBody = document.querySelector('#activeOrdersTable tbody');
        const completedOrdersTableBody = document.querySelector('#completedOrdersTable tbody');
        activeOrdersTableBody.innerHTML = '';
        completedOrdersTableBody.innerHTML = '';

        activeOrders.forEach(order => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${order.id}</td>
                <td>${order.customerName}</td>
                <td>${order.price}</td>
                <td>${order.lastModified}</td>
                <td><button onclick="editOrder(${order.id})">Edit/View</button></td>
                <td><button onclick="completeOrder(${order.id})">Complete</button></td>
            `;
            activeOrdersTableBody.appendChild(row);
        });

        completedOrders.forEach(order => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${order.id}</td>
                <td>${order.customerName}</td>
                <td>${order.price}</td>
                <td>${order.lastModified}</td>
                <td><button onclick="viewOrder(${order.id})">View</button></td>
            `;
            completedOrdersTableBody.appendChild(row);
        });
    };

    // Functions to handle modals
    window.openModal = (modalId) => {
        document.getElementById(modalId).style.display = 'flex';
    };

    window.closeModal = (modalId) => {
        document.getElementById(modalId).style.display = 'none';
    };

    // Function to handle creating a new order
    document.getElementById('createOrderForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const customerName = document.getElementById('customerName').value;
        const price = document.getElementById('price').value;
        const newOrder = {
            id: activeOrders.length + 1,
            customerName,
            price,
            lastModified: new Date().toLocaleString()
        };
        activeOrders.push(newOrder);
        closeModal('createOrderModal');
        renderOrdersTable();
    });

    // Function to handle editing an order
    window.editOrder = (orderId) => {
        currentEditingOrder = activeOrders.find(order => order.id === orderId);
        if (currentEditingOrder) {
            document.getElementById('editCustomerName').value = currentEditingOrder.customerName;
            document.getElementById('editPrice').value = currentEditingOrder.price;
            openModal('editOrderModal');
        }
    };

    document.getElementById('editOrderForm').addEventListener('submit', (e) => {
        e.preventDefault();
        if (currentEditingOrder) {
            currentEditingOrder.customerName = document.getElementById('editCustomerName').value;
            currentEditingOrder.price = document.getElementById('editPrice').value;
            currentEditingOrder.lastModified = new Date().toLocaleString();
            closeModal('editOrderModal');
            renderOrdersTable();
        }
    });

    // Function to handle viewing a completed order
    window.viewOrder = (orderId) => {
        const order = completedOrders.find(order => order.id === orderId);
        if (order) {
            document.getElementById('viewCustomerName').value = order.customerName;
            document.getElementById('viewPrice').value = order.price;
            openModal('viewOrderModal');
        }
    };

    // Function to handle completing an order
    window.completeOrder = (orderId) => {
        const orderIndex = activeOrders.findIndex(order => order.id === orderId);
        if (orderIndex !== -1) {
            const [completedOrder] = activeOrders.splice(orderIndex, 1);
            completedOrders.push(completedOrder);
            renderOrdersTable();
        }
    };

    // Initial render
    initTheme();
    renderLoginPage();

    // Set up the theme toggle switch
    const themeSwitch = document.getElementById('themeSwitch');
    themeSwitch.addEventListener('change', toggleTheme);
});
